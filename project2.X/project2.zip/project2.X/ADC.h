#ifndef ADC_H
#define	ADC_H

uint16_t do_ADC(void);

#endif	/* ADC_H */

