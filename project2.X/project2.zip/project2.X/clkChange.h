#ifndef CLKCHANGE_H
#define	CLKCHANGE_H

#include <xc.h>

// Function declarations
void newClk(unsigned int clkval);

#endif	/* CLKCHANGE_H */

