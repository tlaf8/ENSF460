#ifndef CLOCK_H
#define	CLOCK_H

void InitClock();

#endif	/* CLOCK_H */

