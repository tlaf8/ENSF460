#ifndef IOS_H_
#define IOS_H_

#include <stdint.h>

void IOinit();

void IOcheck(uint16_t *PB1, uint16_t *PB2, uint16_t *PB3);

#endif /* IOS_H_ */
