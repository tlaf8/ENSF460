#ifndef TIMEDELAY_H
#define	TIMEDELAY_H

void IOinit(void);
void IOcheck(void);

#endif	/* TIMEDELAY_H */

